package com.itheima.topline.bean;
public class PythonBean {
    private int id;           //开班Id
    private String address; //开班地址
    private String content; //开班内容
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
}
