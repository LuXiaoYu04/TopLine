package com.itheima.topline.utils;

public class Constant {
    public static final String WEB_SITE = "https://luxiaoyu-yun.oss-cn-hangzhou.aliyuncs.com/topline";
    public static final String REQUEST_AD_URL = "/home_ad_list_data.json";
    public static final String REQUEST_NEWS_URL = "/home_news_list_data.json";
    public static final String REQUEST_PYTHON_URL = "/python_list_data.json";
    public static final String REQUEST_VIDEO_URL = "/video_list_data.json";
    //星座界面接口
    public static final String REQUEST_CONSTELLATION_URL = "/constellation_data.json";
    //星座选择界面接口
    public static final String REQUEST_CHOOSE_CONSTELLATION_LIST_URL = "/choose_constellation_list_data.json";
}
